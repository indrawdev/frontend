<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<h2>Contact Person</h2>
<p>PT. LABFUTSAL INDONESIA</p>
<p>Gedung Wisma Bakri Lt. 16, Jl. Rasuna Said (Kuningan) <br>Jakarta Selatan</p>
<p><i class="address card icon"></i> <strong>085294076828</strong></p>