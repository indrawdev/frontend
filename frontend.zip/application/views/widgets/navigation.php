<div class="ui fixed inverted menu">
	<div class="ui container">
		<a href="<?php echo base_url(); ?>" class="header item">
			<img class="logo" src="<?php echo base_url('assets/images/logo.png'); ?>">LABFUTSAL
		</a>
		<a href="<?php echo base_url(); ?>" class="item">Home</a>
		<a href="<?php echo base_url('checkout'); ?>" class="item">Checkout</a>
		<a href="<?php echo base_url('konfirmasi'); ?>" class="item">Konfirmasi</a>
		<a href="<?php echo base_url('kontak'); ?>" class="item">Kontak</a>
	</div>
</div>