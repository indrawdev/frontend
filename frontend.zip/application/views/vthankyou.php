<h2>Terima Kasih</h2>
<div class="ui positive message">
	<i class="close icon"></i>
	<div class="header">Order Number</div>
	<?php echo $this->session->flashdata('order'); ?>
	<br> Sedang di proses
</div>